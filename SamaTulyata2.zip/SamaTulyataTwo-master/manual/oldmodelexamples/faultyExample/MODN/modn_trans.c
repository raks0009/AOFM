

void main()
{
 int s;
 int i;
 int n;
 int a;
 int b;
 int sout;
      if (i<0&&s<0)
       {
        s = (s - n);
       }  /* end of if-else (sT3_10)*/
      else
      break;
   } while (1);

  sout = s;

}

