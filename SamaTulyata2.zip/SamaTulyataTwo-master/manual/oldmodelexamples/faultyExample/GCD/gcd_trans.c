#include <stdio.h>
// extern int main(void);
// extern void _main();

void main(void)
{
 int y1;
 int y2;
 int res;
 int yout;
 int i;


 int returnVar_main;
  res = 1;
  i = 0;
  returnVar_main = 0;
  do
   {
    y1 = (y1 != y2);
    break;
   } while (1);

  res = (res * y1);
  yout = res;
  printf ("%d", yout);

}

