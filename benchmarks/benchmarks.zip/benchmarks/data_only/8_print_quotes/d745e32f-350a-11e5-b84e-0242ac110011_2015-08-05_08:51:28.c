/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#include<string.h>
int main(){
    printf(" 'a' is not the same as \"a\".");
		return 0;
}