/*compile-errors:e148_263189.c:3:37: warning: unknown escape sequence '\.'
printf("'a' is not the same as \"a\"\. ");
                                    ^~
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main(){
printf("'a' is not the same as \"a\"\. ");
	
	return 0;
}