#include<stdio.h>
int main(){

	printf("'a' is not the same as \"a\".\n");
	return 0;
}