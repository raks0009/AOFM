/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main(){
    printf("\n 'a' is not the same as \"a\"." );
	return 0;
}