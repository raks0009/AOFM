/*compile-errors:e148_263196.c:3:40: warning: unknown escape sequence '\.'
printf ("\'a\' is not the same as \"a\"\.");
                                       ^~
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main () {
printf ("\'a\' is not the same as \"a\"\.");
	return 0;
}