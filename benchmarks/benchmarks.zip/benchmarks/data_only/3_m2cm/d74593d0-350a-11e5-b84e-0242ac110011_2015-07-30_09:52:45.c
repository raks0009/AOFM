/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int cf=100;
	int m=13;
	int cm=m*cf;
	printf("%d",cm);
	return 0;
}