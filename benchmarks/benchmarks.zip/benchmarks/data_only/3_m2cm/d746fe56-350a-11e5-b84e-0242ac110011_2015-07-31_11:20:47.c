/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
int p=100*13;
printf ("%d",p);
	return 0;
}