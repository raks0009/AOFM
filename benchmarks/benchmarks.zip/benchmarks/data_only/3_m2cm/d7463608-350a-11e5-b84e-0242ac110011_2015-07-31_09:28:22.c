/*execute-result:OK*/
/*compile-errors:e147_262165.c: In function 'main':
e147_262165.c:5:2: warning: statement with no effect [-Wunused-value]
  ("13*100m");
  ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	("13*100m");
	return 0;
}
