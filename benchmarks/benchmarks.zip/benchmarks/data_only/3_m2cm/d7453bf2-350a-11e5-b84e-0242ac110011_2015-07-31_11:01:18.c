/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int length;
	length = 13*100;
	printf("%d",length);
	return 0;
}