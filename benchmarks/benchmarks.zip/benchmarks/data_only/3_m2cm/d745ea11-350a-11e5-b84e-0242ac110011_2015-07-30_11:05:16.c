/*execute-result:OK*/
/*compile-errors:e147_262088.c: In function 'main':
e147_262088.c:6:11: warning: unused variable 'b' [-Wunused-variable]
  int a=13,b;
           ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	// Fill this area with your code.
	int a=13,b;
	printf("value of b = %d" ,a*100);
	return 0;
}
