/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	// Fill this area with your code.
	printf("%d",13*100);
	return 0;
}