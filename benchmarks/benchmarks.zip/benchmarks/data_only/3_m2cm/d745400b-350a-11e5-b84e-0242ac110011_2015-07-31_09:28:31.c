/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	// Fill this area with your code.
	printf("Since 1M=100CM\n Hence 13M=1300CM");
	return 0;
}
