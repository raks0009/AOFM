/*compile-errors:e147_262232.c: In function 'main':
e147_262232.c:4:17: warning: unused variable 'a' [-Wunused-variable]
 int main() {int a=13,b;
                 ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {int a=13,b;
b=13*100;
printf("%d",b);
	// Fill this area with your code.
	return 0;
}
