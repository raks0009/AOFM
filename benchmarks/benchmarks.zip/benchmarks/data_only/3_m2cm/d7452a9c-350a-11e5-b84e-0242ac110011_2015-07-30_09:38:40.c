/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int n1;
    n1=13;
    n1=n1*100;
    printf("%d",n1);
	// Fill this area with your code.
	return 0;
}