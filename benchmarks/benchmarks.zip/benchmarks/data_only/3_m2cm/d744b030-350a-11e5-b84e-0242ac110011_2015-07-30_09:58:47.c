/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
int main() {
	int a,b=0;
	printf("enter a number");
	scanf("%d",&a);
b=(b+a%10)*10;
if(a==b){
    printf("number is palindrom");}
    else
    printf("number is not palindrom");
	return 0;
}
