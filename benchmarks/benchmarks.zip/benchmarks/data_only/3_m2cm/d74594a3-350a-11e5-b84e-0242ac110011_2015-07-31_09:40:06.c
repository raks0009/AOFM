/*compile-errors:e147_262025.c: In function 'main':
e147_262025.c:5:6: warning: left-hand operand of comma expression has no effect [-Wunused-value]
 ("%d",1300); return 0;
      ^
e147_262025.c:5:1: warning: statement with no effect [-Wunused-value]
 ("%d",1300); return 0;
 ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
("%d",1300);	return 0;
}