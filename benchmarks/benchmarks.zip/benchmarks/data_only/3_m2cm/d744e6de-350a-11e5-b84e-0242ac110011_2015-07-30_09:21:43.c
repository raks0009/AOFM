/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int cm;
	cm=13*100;
	printf("13 m into cm equals :%d",cm);
	return 0;
}
