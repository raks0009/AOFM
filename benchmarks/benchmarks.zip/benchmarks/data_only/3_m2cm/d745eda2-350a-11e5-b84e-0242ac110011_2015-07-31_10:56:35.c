/*compile-errors:e147_262093.c: In function 'main':
e147_262093.c:5:6: warning: unused variable 'm' [-Wunused-variable]
  int m=13;
      ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int m=13;
	int cm=13*100;
	printf("%d",cm);
	return 0;
}
