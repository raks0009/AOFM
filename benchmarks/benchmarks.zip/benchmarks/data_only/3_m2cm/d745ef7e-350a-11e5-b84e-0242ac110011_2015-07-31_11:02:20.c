/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int x=13;
	int product =x*100;
	printf("%d",product);
	return 0;
}