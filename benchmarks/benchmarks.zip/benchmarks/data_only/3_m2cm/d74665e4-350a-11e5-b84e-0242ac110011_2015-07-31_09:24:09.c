/*compile-errors:e147_262213.c: In function 'main':
e147_262213.c:5:9: warning: unused variable 'c' [-Wunused-variable]
  int m, c; 
         ^
e147_262213.c:5:6: warning: unused variable 'm' [-Wunused-variable]
  int m, c; 
      ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int m, c; 
	printf("1300");
	return 0;
}