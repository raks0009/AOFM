/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	// Fill this area with your code.
	int x,y;
	x=10;
	
	y=20;
	printf("%d",x);
	printf("%d",y);
	return 0;
}
