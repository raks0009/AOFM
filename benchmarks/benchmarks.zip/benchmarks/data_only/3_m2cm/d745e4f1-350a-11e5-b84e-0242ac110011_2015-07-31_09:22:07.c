/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int c=13*100;
	printf("%d",c);// Fill this area with your code.
	return 0;
}
