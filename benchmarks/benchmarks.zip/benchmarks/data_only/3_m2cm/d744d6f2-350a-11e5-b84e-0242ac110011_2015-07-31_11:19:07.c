/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    printf("Enter number\n");
    scanf("%d",&n);
    printf("%d",(n*100));
	return 0;
}