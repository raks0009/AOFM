/*execute-result:OK*/
/*compile-errors:e147_262176.c: In function 'main':
e147_262176.c:5:2: warning: format '%d' expects a matching 'int' argument [-Wformat=]
  printf("%d 13 * 100");
  ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	printf("%d 13 * 100");
	return 0;
}