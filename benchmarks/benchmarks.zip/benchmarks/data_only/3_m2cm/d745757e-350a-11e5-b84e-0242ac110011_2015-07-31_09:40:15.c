/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int a;
	a=13*100;
	printf("%d", a);
	return 0;
}