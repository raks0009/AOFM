/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int am=13;
	int acm=am*100;
	printf("%d",acm);
	return 0;
}