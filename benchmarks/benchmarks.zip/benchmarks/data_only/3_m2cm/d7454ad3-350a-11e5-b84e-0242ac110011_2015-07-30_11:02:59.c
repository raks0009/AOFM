/*execute-result:OK*/
/*compile-errors:e147_261955.c: In function 'main':
e147_261955.c:5:9: warning: unused variable 'm' [-Wunused-variable]
     int m=13;
         ^
e147_261955.c:8:11: warning: 'd' is used uninitialized in this function [-Wuninitialized]
     printf("%d",d);
           ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int m=13;
    int d;
   // c=m*100;
    printf("%d",d);
	// Fill this area with your code.
   return 0;
}