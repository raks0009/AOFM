/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int x=13,y;
	y=x*100;
	printf("%d",y);

	return 0;
}
