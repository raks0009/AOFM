/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int conversionFactor=100; 
	int m=13; 
	int cm=m*conversionFactor; 
	printf("%d",cm);
	return 0;
}