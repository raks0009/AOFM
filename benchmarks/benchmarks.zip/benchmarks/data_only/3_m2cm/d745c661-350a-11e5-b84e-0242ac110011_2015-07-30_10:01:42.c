/*execute-result:OK*/
/*compile-errors:e147_262072.c: In function 'main':
e147_262072.c:5:5: warning: format '%d' expects a matching 'int *' argument [-Wformat=]
     scanf("%d");
     ^*/
/*compile-result:1*/
/*save-event:compile*/
# include <stdio.h>
int main()
{
    printf("hello world");
    scanf("%d");
    return 0;
}
