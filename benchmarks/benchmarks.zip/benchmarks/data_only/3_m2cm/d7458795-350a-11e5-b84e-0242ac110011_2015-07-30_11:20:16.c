/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int a,b,c,d,e=0;
	scanf("%d",&a);
	b=a;
	c=a%10;
	d=a/10;
	e=d*10+c;
	if(e==b) printf("YES");
	else printf("NO");
	return 0;
}