/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int M,CM;
	M=13;
	CM=M * 100;
	printf("%d",CM);
	return 0;
}
