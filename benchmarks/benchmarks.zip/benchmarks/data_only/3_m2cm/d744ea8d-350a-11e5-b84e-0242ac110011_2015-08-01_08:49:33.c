/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int a, b;
	printf("Enter the number:\n");
	scanf("%d", &a);
	printf("The number in cm. is:");
	b=a*100;
	scanf("%d", &b);
	return 0;
}