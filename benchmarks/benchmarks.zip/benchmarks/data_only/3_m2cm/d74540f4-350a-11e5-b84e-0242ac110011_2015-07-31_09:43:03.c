/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
int m=13;
int cm=m*100;
printf("%d" ,cm);// Fill this area with your code.
	return 0;
}
