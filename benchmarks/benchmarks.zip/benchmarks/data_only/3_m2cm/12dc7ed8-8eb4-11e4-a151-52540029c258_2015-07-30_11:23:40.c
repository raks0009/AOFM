/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int meters = 13, centimeters;
	centimeters = meters * 100;
	printf("%d", centimeters);
	return 0;
}
