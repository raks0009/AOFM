/*compile-errors:e147_262003.c: In function 'main':
e147_262003.c:5:8: warning: unused variable 'b' [-Wunused-variable]
  int a,b;
        ^
e147_262003.c:5:6: warning: unused variable 'a' [-Wunused-variable]
  int a,b;
      ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int a,b;
	printf("1300");
	return 0;
}
