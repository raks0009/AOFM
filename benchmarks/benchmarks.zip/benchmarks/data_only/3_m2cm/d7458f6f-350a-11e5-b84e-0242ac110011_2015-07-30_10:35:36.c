/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() 
{
int a=13;
int b=a*100;
printf("%d",b);
	return 0;
}
