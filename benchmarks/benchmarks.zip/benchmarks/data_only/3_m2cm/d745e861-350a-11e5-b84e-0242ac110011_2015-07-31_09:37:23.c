/*compile-errors:e147_262086.c: In function 'main':
e147_262086.c:5:9: warning: variable 'm' set but not used [-Wunused-but-set-variable]
     int m,cm;
         ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int m,cm;
    m=13;
    cm=13*100;
	printf("%d\n",cm);
	return 0;
}
