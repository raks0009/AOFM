/*execute-result:OK*/
/*compile-errors:e147_261973.c: In function 'main':
e147_261973.c:5:9: warning: variable 'a' set but not used [-Wunused-but-set-variable]
     int a;
         ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int a;
    a=13;
    int b=13*100;
    printf("%d",b);
	return 0;
}
