/*compile-errors:e147_262216.c: In function 'main':
e147_262216.c:6:6: warning: unused variable 'a' [-Wunused-variable]
  int a=13;
      ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	// Fill this area with your code.
	int a=13;
	int b=13*100;
	printf ("%d",b);
	return 0;
}
