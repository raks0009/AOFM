/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int x;int y;
	printf("enter no.");
	scanf("%d\n",&x);
	y=x*100;
	printf("%d\n",y);
	return 0;
}
	
