/*compile-errors:e147_262151.c: In function 'main':
e147_262151.c:6:1: warning: format '%d' expects argument of type 'int *', but argument 2 has type 'int' [-Wformat=]
 scanf("%d", cm);
 ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
int cm=0 , m;
scanf("%d", cm);
m=100*cm;
printf("%d", m);// Fill this area with your code.
	return 0;
}
