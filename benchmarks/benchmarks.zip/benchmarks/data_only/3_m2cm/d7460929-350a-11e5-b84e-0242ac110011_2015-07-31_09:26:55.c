/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int a,b,c;
    a=13;
    b=100;
    c=a*b;
    printf("%d",c);
	// Fill this area with your code.
	return 0;
}