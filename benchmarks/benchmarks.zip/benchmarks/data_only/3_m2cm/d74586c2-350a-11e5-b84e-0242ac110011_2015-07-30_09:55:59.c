/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	//Fill this area with your code.
	int x,y;
	scanf("%d",&x);
	y=x*100;
	printf("%d",y);
	return 0;
}