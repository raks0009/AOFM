/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() { int n,m;
n=13;
m=n*100;
printf("converting 13m into centimeters..........");
printf("%d",m);
printf("cms");

return 0;}