/*execute-result:RT*/
/*compile-errors:e147_262247.c: In function 'main':
e147_262247.c:11:5: warning: passing argument 1 of 'printf' makes pointer from integer without a cast [enabled by default]
     printf(a*100);
     ^
In file included from /usr/include/stdio.h:937:0,
                 from e147_262247.c:1:
/usr/include/x86_64-linux-gnu/bits/stdio2.h:102:1: note: expected 'const char * __restrict__' but argument is of type 'int'
 printf (const char *__restrict __fmt, ...)
 ^
e147_262247.c:11:5: warning: format not a string literal and no format arguments [-Wformat-security]
     printf(a*100);
     ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	// Fill this area with your code.
	int a;
    printf("enter ur input in metres==>");
    scanf("%d",&a);
    
    printf("\nanswer in cms. is===>");
    printf(a*100);
	return 0;
}