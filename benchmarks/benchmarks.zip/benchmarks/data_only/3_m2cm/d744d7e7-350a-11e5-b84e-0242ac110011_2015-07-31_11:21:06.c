/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int metre=13;
	
	
	
	printf("%i",metre*100);
	
	return 0 ;
	
}