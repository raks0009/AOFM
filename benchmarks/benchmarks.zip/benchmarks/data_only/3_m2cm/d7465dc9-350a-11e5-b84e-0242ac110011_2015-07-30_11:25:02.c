/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#include<ctype.h>
int main()
{int x,p=0,n;
scanf("%d",&x);
while(p!=10)
{n=0;
  while(n!=p)
 {printf("*");
 n++;
}p++;
printf("\n");}
return 0;
}