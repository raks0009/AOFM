/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	int m,cm;
		m=13;
	cm=m*100;
	printf ("%d",cm);
	return 0;
}
