/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int a=13;
    printf("%d",a*100);
	// Fill this area with your code.
	return 0;
}