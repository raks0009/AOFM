/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	// Fill this area with your code.
	int c = 13;
	printf("%d",c*100);
	return 0;
}