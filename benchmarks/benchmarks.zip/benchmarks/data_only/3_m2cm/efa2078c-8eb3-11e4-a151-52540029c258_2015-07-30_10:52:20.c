/*compile-errors:e147_262014.c: In function 'main':
e147_262014.c:5:9: warning: unused variable 'a' [-Wunused-variable]
     int a;
         ^*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int a;
    printf("1300");
	return 0;
}
