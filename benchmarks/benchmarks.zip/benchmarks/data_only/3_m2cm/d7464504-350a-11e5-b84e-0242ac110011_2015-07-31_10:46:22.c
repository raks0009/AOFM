/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {

    int age;
    
    printf("how old are you? \n");
    scanf("%d", &age);
    
    if(age >= 18 ){
        printf("hello u r welcome");
    }else{
        printf("sorry");
    }

	
	return 0;
}