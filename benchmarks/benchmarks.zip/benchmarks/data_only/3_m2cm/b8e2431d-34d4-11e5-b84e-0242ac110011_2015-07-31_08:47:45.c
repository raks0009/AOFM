/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>
#include <stdlib.h>

int main() {
	// Fill this area with your code.
	int a;
	a = 13;
	a = a * 100;
	printf("%d",a);
	return 0;
}
